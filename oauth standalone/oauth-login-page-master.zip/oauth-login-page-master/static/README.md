Add your static files to this folder (i.e. CSS and images).
