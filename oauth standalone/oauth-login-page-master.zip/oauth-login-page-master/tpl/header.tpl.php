
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head> 
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        
	<link rel="icon" type="image/png" href="%image_icon%" />
        
	<title>%page_title_prefix% - Login</title>
     
	<!-- START Meta Information -->
	<meta name="author" content="%page_author%" />

	<meta name="copyright" content="%page_copyright%" />

	<meta name="robots" content="noindex,nofollow,noarchive,nosnippet,noimageindex" />
	<!-- END Meta Information -->
    
        <!-- START Style Sheets -->
        <link rel="stylesheet" type="text/css" media="all" href="%css_file%" /> 
        <!-- END Style Sheets -->
     </head>

<body id="lp_body">

<span id="lp_box1">%lp_box1%</span>
<span id="lp_box2">%lp_box2%</span>
<span id="lp_box3">%lp_box3%</span>


