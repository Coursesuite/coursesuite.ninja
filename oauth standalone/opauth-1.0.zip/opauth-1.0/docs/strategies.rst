Available strategies
====================

The current version of Opauth has strategies for the following providers

==============  =============== ==================
Provider        Maintainer      Composer require
==============  =============== ==================
Facebook        Opauth          opauth/facebook
Twitter         Opauth          opauth/twitter
Google          Opauth          opauth/google
GitHub          Opauth          opauth/github
LinkedIn        Opauth          opauth/linkedin
Live            Opauth          opauth/live
Elance          augusto-cdxs    opauth/elance
==============  =============== ==================

.. _create:

Create a strategy
-----------------

If there is no strategy listed for your favorite provider, it's easy to create one yourself.

More info soon..
