Support
=======

There are several ways to get support for Opauth:

- Discussion group: `Google Groups <https://groups.google.com/group/opauth>`_

  Feel free to post any questions to the discussion group.

- Issues: Github Issues

- Twitter: @uzyn

- Email me: chua@uzyn.com

- IRC: #opauth on Freenode
